Stored, not compressed.
